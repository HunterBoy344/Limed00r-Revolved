#!/bin/sh
if [ "$(id -u)" -ne 0 ];
  then echo "You forgot to run su before running the command! Run su then ./install.sh"
  exit
fi
installdir=$(pwd)
dpkg -i tar_1.29-10_iphoneos-arm.deb
cd Limed00r13_series3_beta2
echo "Copying files..."
tar -cf - * | tar -C / --keep-directory-symlink -xf -
echo "Finished copying files."
echo "Deleting old wallpapers..."
rm -rf /var/stash/Wallpaper/*
echo "Copying new wallpapers..."
cd ../Wallpaper
cp -f ./* /var/stash/Wallpaper/
echo "Adding IPG repo to Cydia..."
cd /etc/apt/sources.list.d/
if ! grep -q "deb http://cydia.invoxiplaygames.uk/ ./" cydia.list && ! grep -q "deb http://cydia.invoxiplaygames.uk/ ./" sources.list;
  then echo "deb http://cydia.invoxiplaygames.uk/ ./">>sources.list
fi
cd $installdir

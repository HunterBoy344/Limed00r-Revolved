#!/bin/sh
if [ "$(id -u)" -ne 0 ];
  then echo "You forgot to run su before running the command! Run su then ./install.sh"
  exit
fi
themes_dir=$(find /private/var/stash/ -type d -name "*Themes*")
cd WinterBoardThemes
echo "Copying themes..."
tar -cf - * | tar -C $themes_dir -xf -
cd ..
rm -rf WinterBoardThemes
echo "Done! Apply themes in WinterBoard."
rm install.sh
